Taxonomy Navigator Module

What this does?
Perhaps I should first talk about what took me to create this module.
I had the need to have a navigation block that shows the taxonomy terms of a category. I needed that this links refer to a view passing the term id as a parameter and that the term be highlighted as active if viewing a node that contains that term or if looking at the view with that term as parameter.

So, I created this simple module to do exactly that, and it is configurable to match your needs and be able to change the base view or path for those links.

Resume of characteristics:
* Enable a navigation block for each taxonomy category and enable the possibility to set a base link for each block links passing the term id as parameter.
* If you are in a node that contains one or more terms that are in that navigation block it will mark those term links as active.
* If you are in the base path you set (taxonomy/term/$tid by default) plus the term id it will be mark as active in the block.
* You can enable any number of navigation blocks and control them as any other block.

Optional Features

List all vocabulary terms. if you have in your drupal configuration the module "vocabulary_list_nodes" http://drupal.org/project/vocabulary_list_nodes, 
the Taxonomy Navigator will add a new entry at the top of block ti list all term in your specific vocabulary 

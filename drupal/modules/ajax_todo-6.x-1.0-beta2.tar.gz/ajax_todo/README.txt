/**************************************************************************
  *  The beginnings of this script was found at http://www.codepost.org/view.php?id=120
  *  Posted by Erik on Feb 10 2006 @ 13:41
  *
  *  Name: Ajax-Mysql todo list
  *
  *  Edited on Nov. 29 2007 by Chris Hess (http://cjhess.com)
  *  Ported to Drupal by Yonas Yanfa (yonas.yanfa@kudoscoins.com)
  *
  **************************************************************************/



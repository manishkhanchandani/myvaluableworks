<div id="banner3">
  <?php if (!empty($block->subject)): ?>
    <h2><?php print $block->subject ?></h2>
  <?php endif;?>	
  <div class="content">
    <?php print $block->content ?>
  </div>
</div>
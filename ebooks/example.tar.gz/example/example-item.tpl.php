<div><?php print $name; ?></div>
<div><?php print $mail; ?></div>

<?php 
class CurlHandler
{
  private $curl_handler;
  private $url;
  private $user_agent       = "Trulia curl handler";
  private $return_transfer  = 1;
  private $timeout          = "90";
  private $follow_location  = 0;
  private $verify_peer      = 0;
  private $verify_host      = 0;
  private $forbid_reuse     = true;
  private $curl_type        = "post";

  private $basic_auth = false;
  private $username;
  private $password;

  public function __construct()
  {
    $this->curl_handler = curl_init();
  }

  public function set_url($url)
  {
    $this->url = $url;
  }

  public function set_user_agent($user_agent = "automated test")
  {
    $this->user_agent = $user_agent;
  }

  public function set_return_transfer($return_transfer = 1)
  {
    $this->return_transfer = $return_transfer;
  }

  public function set_timeout($timeout = 90)
  {
    $this->timeout = $timeout;
  }

  public function set_follow_location($follow_location = 0)
  {
    $this->follow_location;
  }

  public function set_verify_peer($verify_peer = 0)
  {
    $this->verify_peer;
  }

  public function set_verify_host($verify_host = 0)
  {
    $this->verify_host;
  }
  
  public function set_forbid_reuse($forbid_reuse = true)
  {
    $this->forbid_reuse;
  }

  public function set_curl_type($type = "post")
  {
    $this->curl_type = $type;
  }

  public function set_basic_authorization($username, $password)
  {
    $this->basic_auth = true;
    $this->username = $username;
    $this->password = $password;
  }
  /**
   * shared curl parameters
   */
  protected function curl_init()
  {
    curl_setopt($this->curl_handler, CURLOPT_USERAGENT, $this->user_agent);

    if ($this->basic_auth)
    {
      curl_setopt($this->curl_handler, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
      curl_setopt($this->curl_handler, CURLOPT_USERPWD, $this->username . ":" . $this->password);
    }

    curl_setopt($this->curl_handler, CURLOPT_RETURNTRANSFER, $this->return_transfer); // return into a variable
    curl_setopt($this->curl_handler, CURLOPT_TIMEOUT, $this->timeout); // times out after 90 secs
    curl_setopt($this->curl_handler, CURLOPT_FOLLOWLOCATION, $this->follow_location); // do not follow
    curl_setopt($this->curl_handler, CURLOPT_SSL_VERIFYPEER, $this->verify_peer); // this line makes it work under https
    curl_setopt($this->curl_handler, CURLOPT_SSL_VERIFYHOST, $this->verify_host); //verifies ssl certificate
    curl_setopt($this->curl_handler, CURLOPT_FORBID_REUSE, $this->forbid_reuse); //forces closure of connection when done
  }
  /**
   * package form data
   */
  protected function build_form_data_string($form_vars)
  {
    $form_data = '';
    if (sizeof($form_vars) > 0)
    {
      foreach ($form_vars as $key => $value)
      {
        $form_data .= urlencode($key) . "=" . urlencode($value) . "&";
      }
    }
    return $form_data;
  }
  
  /**
   * post-specific curl
   */
  public function post($form_vars = array())
  {
    $this->curl_init();
    $form_data = $this->build_form_data_string($form_vars);
    curl_setopt($this->curl_handler, CURLOPT_URL, $this->url);
    curl_setopt($this->curl_handler, CURLOPT_POST, 1); //data sent as POST
    curl_setopt($this->curl_handler, CURLOPT_POSTFIELDS, $form_data); //adding post data
    $result = curl_exec($this->curl_handler);
    return $result;
  }
  
  /**
   * get-specific curl
   */
  public function get($form_vars = array(), $parse_json = false)
  {
    $this->curl_init();
    $form_data = $this->build_form_data_string($form_vars);
    curl_setopt($this->curl_handler, CURLOPT_URL, sprintf("%s%s%s", $this->url, ($form_data != '' ? "?" : ""), $form_data));
    $result = curl_exec($this->curl_handler);
    return $parse_json ? json_decode($result) : $result;
  }
}
?>
/* $Id: README.txt,v 1.5.2.1 2008/06/27 04:47:17 augustin Exp $ */

This module causes a user's chosen theme to be used when another user visits his/her profile page, blog, nodes, etc. according to the site settings.

Project page: http://drupal.org/project/blogtheme


--------------------------------------
The module blog_theme is charity-ware.
--------------------------------------

Please contribute back by supporting the charity work of the following web sites. 
None of the web sites listed here are for profit, and none of them carry advertising.
They are all web sites dedicated to creating a better tomorrow for the whole society.

 * http://activistsolutions.org/ Activist Solutions: harvesting grassroots power.
 * htpp://www.reuniting.info/ Reuniting: healing with sexual relationships.
 * http://overshoot.tv/ Overshoot TV: making high quality videos and documentaries promoting environmental and economical sustainability.
 * http://minguo.info/ Minguo.info: promotting better voting systems, and an experiment in direct democracy.
 * http://www.wechange.org/ We Change: because we live in a world of solutions...


You can support those web sites in the following ways:

 * Blog about them.
 * Put links in a block in a sidebar.
 * Put links in any other logical place in your web site, where your visitors will find the information useful.
 * Register and participate if they match your own interest!
 * We also appreciate if, on behalf of this maintainer, you help any charity of your choice, or/and make a donation to them.

Please let the maintainer know about the options you chose. 

Thank you for your support and cooperation.









Module maintainer (since Drupal 4.7):
Augustin Masquilier. http//overshoot.tv/ http://minguo.info/ 

Module Author (up to Drupal 4.6):
David Hill a.k.a. Tatonca  <tatonca_@hotmail.com>

<?php
// $Id: taxonomy-treemenu-view-row-node.tpl.php,v 1.1 2009/04/23 11:07:37 rcrowther Exp $

/**
 * @file taxonomy_treemenu_view_fields.tpl.php
 * Default template to display a list of fields.
 *
 * @ingroup taxonomy_treemenu_templates
 */
?>

  <div class="taxonomy-treemenu-row-node">
      <span class="field-title">
      <?php print l($title, $node_url) ?> 
      </span>
  </div>

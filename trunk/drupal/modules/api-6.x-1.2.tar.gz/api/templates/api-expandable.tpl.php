<div class="api-expandable<?php print (is_null($class) ? '' : ' '. $class) ?>">
  <div class="prompt"><?php print $prompt ?></div>
  <div class="content"><?php print $content ?></div>
</div>

$Id: README.txt,v 1.1 2009/01/13 21:58:24 sutharsan Exp $

DESCRIPTION
-----------

Simplenews Analytics adds Google Analytics tags to links in all simplenews emails.


REQUIREMENTS
------------

 * Simplenews module

INSTALLATION
------------

 1. CREATE DIRECTORY

    Create a new directory "simplenews_analytics" in the sites/all/modules
    directory and place the contents of this simplenews_analytics folder in it.

 2. ENABLE THE MODULE

    Enable the module on the Modules admin page:
      Administer > Site building > Modules

 3. ACCESS PERMISSION

    Simplenews Analytics settings uses the 'administer simplenews settings'
    permission. 

 4. CONFIGURATION

    Configure the module on:
      Administer > Site configuration > Simplenews > Google Analytics tags.

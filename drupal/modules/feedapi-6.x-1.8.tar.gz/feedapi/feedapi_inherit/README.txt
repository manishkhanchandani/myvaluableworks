// $Id: README.txt,v 1.1.2.2.2.2 2009/07/02 16:38:16 aronnovak Exp $

FeedAPI Inherit module

Passes on taxonomy and organic groups properties from feed nodes to feed item nodes.

INSTALLATION

* Go to admin/build/modules and activate the module.
* Go to admin/content/types and activate the FeedAPI Inherit processor for the
  feed content type of your choice.
* This module works only with the FeedAPI Node Item (feedapi_node) processor activated
  for the same feed content type.

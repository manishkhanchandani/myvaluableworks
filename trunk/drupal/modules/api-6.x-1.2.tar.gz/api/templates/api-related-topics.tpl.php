<dl class="api-related-topics">
<?php foreach ($topics as $topic => $description) { ?>
  <dt><?php print $topic ?></dt>
  <dd><?php print $description ?></dd>
<?php } ?>
</dl>

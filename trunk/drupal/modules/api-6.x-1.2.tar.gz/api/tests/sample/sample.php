<?php

/**
 * @file
 * A sample file.
 */

/**
 * A sample function.
 *
 * Use for sample-related purposes.
 *
 * @param $parameter
 *   A generic parameter.
 */
function sample_function($parameter) {
}

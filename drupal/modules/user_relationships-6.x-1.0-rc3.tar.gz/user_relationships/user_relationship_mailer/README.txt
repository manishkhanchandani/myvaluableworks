; $Id: README.txt,v 1.1.2.5 2008/10/01 09:38:11 alexk Exp $

User Relationship Mailer Module
-------------------------------
This is a plugin module for the User Relationships module.

It provides the facility to email users notifications about relationship changes

Please post issues/feedback at http://drupal.org/project/user_relationships


Requirements
------------
Drupal 6
User Relationships Module


Installation
------------
Enable User Relationship Mailer in the "Site building -> modules" administration screen.


Credits
-------
Updated by Alex Karshakevich http://drupal.org/user/183217
Written by Jeff Smick.
Written originally for and financially supported by OurChart Inc. (http://www.ourchart.com)
Thanks to the BuddyList module team for their inspiration

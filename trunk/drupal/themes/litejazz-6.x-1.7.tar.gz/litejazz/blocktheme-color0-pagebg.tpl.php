<div class="customframeblock color0-box-page-bg block block-<?php print $block->module; ?>" id="block-<?php print $block->module; ?>-<?php print $block->delta; ?>">
		<div class="boxborder">
		<div class="bi">
		<div class="bt"><div></div></div>
<div class="custom-inbox">
	<h2 class="title"><?php print $block->subject; ?></h2>
	<div class="content"><?php print $block->content; ?></div>
</div>
		<div class="bb"><div></div></div>
		</div>
	</div>
</div>





<div class="customframeblock rollover-block rollover2-block block block-<?php print $block->module; ?>" id="block-<?php print $block->module; ?>-<?php print $block->delta; ?>">
		<div class="boxborder">
		<div class="bi">
		<div class="bt"><div></div></div>
	<h2 class="title"><?php print $block->subject; ?></h2>
	<div class="content"><?php print $block->content; ?></div>
		<div class="bb"><div></div></div>
		</div>
	</div>
</div>




